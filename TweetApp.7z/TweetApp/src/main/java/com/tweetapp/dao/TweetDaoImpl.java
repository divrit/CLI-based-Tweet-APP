package com.tweetapp.dao;

import java.io.FileInputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.sql.Connection;

import com.tweetapp.model.Tweet;

public class TweetDaoImpl implements TweetDao {

	private Connection con;

	public void Connection() {
		Properties p = new Properties();
		System.out.println("I am in connection");

		try {
			p.load(new FileInputStream("src/main/resources/db.properties"));
			Class.forName(p.getProperty("jdbc.driver"));

			con = DriverManager.getConnection(p.getProperty("jdbc.url"), p.getProperty("jdbc.username"),
					p.getProperty("jdbc.password"));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void insert(Tweet tweet) {
		String query = "insert into tweets(tweet,mail) values(?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(query);

			ps.setString(1, tweet.getTweet());
			ps.setString(2, tweet.getMail());
			int count = ps.executeUpdate();
			if (count > 0)
				System.out.println("Tweet posted!!");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e2) {
			}
		}

	}

	public void fetchAllTweets(String username) {

		String query = "select tweet from tweets where mail=?";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				String tweet = rs.getString("tweet");
				System.out.println(tweet);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}
	
	public void fetchAll() {

		String query = "select mail,group_concat(tweet) as tweets from tweets group by mail";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String mail = rs.getString("mail");
				String tweet = rs.getString("tweets");
				System.out.println("User id :- "+mail+" Tweets : "+tweet);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}
	
	

}
