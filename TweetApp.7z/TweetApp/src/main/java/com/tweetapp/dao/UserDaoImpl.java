package com.tweetapp.dao;

import java.io.FileInputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.tweetapp.Exception.UserNotFoundException;
import com.tweetapp.model.User;
import java.sql.Connection;


public class UserDaoImpl implements UserDao {
	private static Connection con = null;
	private static Properties prop = null;
	
	public void Connection() {

		prop = new Properties();
		try {
			prop.load(new FileInputStream("src/main/resources/db.properties"));
			Class.forName(prop.getProperty("jdbc.driver"));

			con = DriverManager.getConnection(prop.getProperty("jdbc.url"), prop.getProperty("jdbc.username"),
					prop.getProperty("jdbc.password"));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void insert(User user) {

		String query = "insert into users(First_name,Last_name,gender,dob,password,email) values(?,?,?,?,?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, user.getFirstname());
			ps.setString(2, user.getLastname());
			ps.setString(3, user.getGender());
			ps.setDate(4, new java.sql.Date(user.getDob().getTime()));
			ps.setString(5, user.getPassword());
			ps.setString(6, user.getmail());
			int count = ps.executeUpdate();
			if (count > 0)
				System.out.println("User registered successfully!");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (SQLException e2) {
	        }
		}

	}

	public String readPass(String username) {
		UserDao ud = new UserDaoImpl();
	
		ud.Connection();
		String query = "select password from users where email =?";

		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			rs.next();
			String pass=rs.getString("password");
			return pass;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (SQLException e2) {
	        }
		}
		return "";

	
	}
	
	
	public void VerifyUser(String username) throws UserNotFoundException  {
		UserDao ud = new UserDaoImpl();
		ud.Connection();
		String query = "select * from users where email =?";

		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Username is valid");
			}
			else {
				
				throw new UserNotFoundException("User not found!! Please enter a valid user.");
				
			}
				
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (SQLException e2) {
	        }
		}
		

	
	}

	public void setLoginStatus(String mail,boolean b) {
		UserDao ud = new UserDaoImpl();
		ud.Connection();
		String query = "update users set login =? where email =?";

		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setBoolean(1,b);
			ps.setString(2,mail);
		
			int count = ps.executeUpdate();
			if (count > 0)
				System.out.println("Logon status updated");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (SQLException e2) {
	        }
		}
	}
	
	
	public void changePass(String username,String Pass) {
		
		String query="update users set password=? where email=?";
		UserDao ud = new UserDaoImpl();
		ud.Connection();
		try {
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, Pass);
		
			ps.setString(2, username);
			int p = ps.executeUpdate();
			if(p>0)
				System.out.println("Password Updated succefully");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
		
		
		
	}
	
	

}
