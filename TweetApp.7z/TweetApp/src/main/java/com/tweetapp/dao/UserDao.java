package com.tweetapp.dao;

import com.tweetapp.model.User;

public interface UserDao {
	
	public void Connection();
	
	public void insert(User user);
	
	public String readPass(String s);
	
	public void setLoginStatus(String mail, boolean b);
	
	public void VerifyUser(String username) throws Exception;
	
	public void changePass(String username,String Pass);

}
