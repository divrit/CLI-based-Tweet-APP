package com.tweetapp.dao;

import java.util.List;

import com.tweetapp.model.Tweet;

public interface TweetDao {
	
	public void Connection();
	
	public void insert(Tweet tweet);
	
	public void fetchAllTweets(String username) ;
	
	public void fetchAll();
}

