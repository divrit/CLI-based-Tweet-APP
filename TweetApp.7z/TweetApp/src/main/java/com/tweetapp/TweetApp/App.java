package com.tweetapp.TweetApp;

import java.util.Scanner;

import com.tweetapp.dao.UserDao;
import com.tweetapp.dao.UserDaoImpl;
import com.tweetapp.model.User;
import com.tweetapp.service.UserLogin;
import com.tweetapp.service.UserRegistration;

public class App {
	
	public static void main(String[] args) throws Exception {
		Scanner scan = new Scanner(System.in);
		
		while(true) {

		System.out.println("Select Your Option!");

		System.out.println("i.Register");
		System.out.println("ii.Login");
		System.out.println("iii.Forgot Password");
		System.out.println("iv.Logout");

		String option = scan.nextLine();

		if (option.equals("i")) {
			UserRegistration ur = new UserRegistration();
			User u = ur.register();
			UserDao uD = new UserDaoImpl();
			uD.Connection();
			uD.insert(u);

		}
		if (option.equals("ii")) {

			UserLogin ul = new UserLogin();
			ul.login();

		}

		if (option.equals("iii")) {

			UserLogin ul = new UserLogin();
			ul.forgotPassword();;

		}
		
		if (option.equals("iv")) {

			break;

		}

	}
	}
}
