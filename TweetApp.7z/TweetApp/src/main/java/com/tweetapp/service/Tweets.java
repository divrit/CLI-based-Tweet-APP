package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.TweetDao;
import com.tweetapp.dao.TweetDaoImpl;
import com.tweetapp.model.Tweet;

public class Tweets {
	Scanner sc = new Scanner(System.in);
	TweetDao td = new TweetDaoImpl();

	public void loggedIn(String username) {

		while (true) {

			System.out.println("-------------Please select from below functionalities--------------");

			System.out.println("1. Post new tweet");
			System.out.println("2. View all your tweets");
			System.out.println("3. View other registered users and their tweets");
			System.out.println("4. Logout");

			int option = sc.nextInt();
			sc.nextLine();

			if (option == 1) {

				System.out.println("Please enter your tweet");
				String twee = sc.nextLine();

				td.Connection();
				Tweet tweet = new Tweet();
				tweet.setMail(username);
				tweet.setTweet(twee);
				td.insert(tweet);

			}
			if (option == 2) {
				td.Connection();
				td.fetchAllTweets(username);
			}

			if (option == 3) {
				td.Connection();
				td.fetchAll();
			}

			
			if (option == 4) {

			break;
			
			}
			
		}
	}

}
