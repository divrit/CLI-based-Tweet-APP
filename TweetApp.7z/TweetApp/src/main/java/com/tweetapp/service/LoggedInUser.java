package com.tweetapp.service;

public class LoggedInUser {
	
	
	static {
		
		System.out.println("Post a tweet.");
		System.out.println("View my tweets.");
		System.out.println("View all tweets");
		System.out.println("View all Users.");
		System.out.println("Reset password");
		
		
		
		
		
		
	}
	

}
