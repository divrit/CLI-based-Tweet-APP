package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.UserDao;
import com.tweetapp.dao.UserDaoImpl;

public class UserLogin {

	Scanner scan = new Scanner(System.in);

	public void login() {
		System.out.println("Enter Username");
		String username = scan.nextLine();

		UserDao d = new UserDaoImpl();
		try {
			d.VerifyUser(username);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Enter Password");
		String pwd = scan.nextLine();

		String pass = d.readPass(username);
		if (pwd.equals(pass)) {
			System.out.println("Welcome to the TWEET APP!!!!!!");
			d.setLoginStatus(username, true);
			Tweets t=new Tweets();
			t.loggedIn(username);
		}
	}
	
	
	public void forgotPassword() {
		System.out.println("Please enter your User Id");
		String username=scan.nextLine();
		UserDao ud=new UserDaoImpl();
		try {
			ud.VerifyUser(username);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Please enter the password you would like to have");
		String newPass=scan.nextLine();
		ud.changePass(username, newPass);
		
	}

}
