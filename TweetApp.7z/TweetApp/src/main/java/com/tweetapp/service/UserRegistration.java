package com.tweetapp.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.tweetapp.model.User;

public class UserRegistration {

	Scanner scan = new Scanner(System.in);
	User user = new User();

	public User register() throws ParseException {
		System.out.println("Enter Your firstname ");
		user.setFirstname(scan.nextLine());

		System.out.println("Enter Your lastname ");
		user.setLastname(scan.nextLine());

		System.out.println("Enter your Dob");
		String d1 = scan.nextLine();
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-YYYY");
		Date date = format.parse(d1);
		user.setDob(date);

		System.out.println("Enter your Gender");
		user.setGender(scan.nextLine());

		System.out.println("enter your Mail Id");
		user.setmail(scan.nextLine());

		System.out.println("Enter your Password");
		user.setPassword(scan.nextLine());
	
		return user;

	}
}
